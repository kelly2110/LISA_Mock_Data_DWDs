# Testing imports for GW and Noise signal, seeing if object is created, calculating the SNR


from giese_lisa_sens import S_n, Omega_N
from kinetic_energy_fraction import kappaNuMuModel
from ps import PowerSpectrum
import numpy as np
import matplotlib.pyplot as plt
from SNR import calculate_snr_ # Specify main branch --> Folder --> File --> Function / class


f = np.logspace(-1, 1, 5000)
Omega = Omega_N(f, 3, 15)# Lisa Noise Signal
GW = PowerSpectrum(0.4, 50, 200, 0.8).Omega_GW(f) # Lisa possible GW signal

SNR = calculate_snr_(GW, Omega, f)
print (SNR)

#########################################
"""        # Calculate the mean Omega_GW (for now only for the specified frequency, not a range yet)

  def mean_GW(f):
    return np.mean(GW)
    print(f"Mean Omega_GW: {mean_GW}")

        #Calculate St. Dev for each frequency
  def sd_GW (f): 
    print(f"Standard Deviation Omega_GW: {sd_GW}")
    return np.std(GW, dtype=np.float64)
    

    #Minimization function
  def chi_squared(N_c, GW, Omega):
      chi2 = N_c*np.sum(mean_GW(f) - GW - Omega)/sd_GW(f)    #(MEAN - DATA - NOISE / ST.DEV)^2
      return chi2

      # Initial guess for parameters, for this model A and fp_0
  initial_guess = [3, 5-40]

    # Minimize the chi-squared function
  result = minimize(chi_squared, initial_guess, args=(GW, f))

    # Extract the best-fit parameters
  best_fit_params = result.x

  print("Best-fit parameters:", best_fit_params)


#Akaike Information Criterion (AIC)

# def AIC(k):
# return chi_squared(params, GW, Omega) + 2*k
 """