import numpy as np
import matplotlib.pyplot as plt
from ps import PowerSpectrum
from giese_lisa_sens import Omega_N

def calculate_S(frequencies, N_c, PS):
    
    # Precompute frequency-dependent quantities outside the loop  
    Total_Signal = []

    for _ in range(N_c):
        Signal_f = []
        for f in frequencies:
            GW = (PS.Omega_GW(f))
            st_dev = np.sqrt(GW)
            # Generate random numbers from a Gaussian distribution with zero mean and the specified standard deviation
            G_1 = np.random.normal(loc=0.0, scale=st_dev)
            G_2 = np.random.normal(loc=0.0, scale=st_dev)
            N = (G_1**2 + G_2**2) / 2
            Signal_f.append(N)
            print(Signal_f)

        Total_Signal.append(np.array(Signal_f))

    return np.array(Total_Signal)


if __name__ == "__main__":
      # Amount of data points for each frequency
    f_low = np.arange(0.00003, 0.001, 0.000001)
    f_middle = np.arange(0.001, 0.01, 0.00005)
    f_high = np.arange(0.01, 0.5, 0.001)
    frequencies = np.concatenate((f_low, f_middle, f_high))
    print(frequencies.shape)
    P1 = PowerSpectrum(0.6, 50, 180, 0.8)
    GW = P1.Omega_GW(frequencies)
    N_c = 20 # Number of datapoints to be generated for each f
    NOISE = calculate_S(frequencies, N_c, P1)

    # Want to obtain the mean and st. dev for each frequency over N_c points
    # Calculating mean for each f
    mean_values = np.mean(NOISE, axis=0)
    print("Shape of mean_values array:", mean_values.shape)
    print("Mean values array:", mean_values)

    # Calculating standard deviation for each f
    std_dev_values = np.std(NOISE, axis=0)
    print("Shape of st_dev_values array:", std_dev_values.shape)
    print("Standard Deviation Values array:", std_dev_values)

    # Plotting sample and model data
    plt.loglog(frequencies, mean_values, color='blue', label="Sample Data") # Sample data
    plt.loglog(frequencies, GW, color='red', label="Model Signal" )
    plt.loglog(frequencies, Omega_N(frequencies, 3, 15), color='green', label="Model Noise Data") # Model Noise data
    plt.legend()
    plt.title(r'Sample vs Model Data Values for LISA Noise Signal')
    plt.xlabel(r'$Frequency$' + "  " + r'$(Hz)$')
    plt.ylabel(r'$h^{2}\Omega(f)$')
    plt.grid = 'True'
    plt.savefig("Sample_vs_Model_Noise")
    plt.show()