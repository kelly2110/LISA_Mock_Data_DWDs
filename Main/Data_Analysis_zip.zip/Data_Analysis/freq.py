import numpy as np
f_low = np.arange(0.00003, 0.001, 0.000001)
f_middle = np.arange(0.001, 0.01, 0.00005)
f_high = np.arange(0.01, 0.5, 0.001)
frequencies = np.concatenate((f_low, f_middle, f_high))
np.savetxt('frequencies.csv', frequencies, delimiter=',')
print(frequencies.size)
print(frequencies)